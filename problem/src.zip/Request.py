class Request:
    def __init__(self,video,endpoint,number):
        self.video = video
        self.endpoint = endpoint
        self.number = number