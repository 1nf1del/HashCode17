class Video:
    def __init__(self,id,size):
        self.size = size
        self.id = id
        self.totalrequests=0

